import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SPEAKER_SELECTED from '@salesforce/messageChannel/SpeakerSelected__c';

import getSpeaker from '@salesforce/apex/SpeakerController.getSpeaker';
import checkAvailability from '@salesforce/apex/SpeakerController.checkAvailability';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class BookSession extends LightningElement {
    speakerId;
    speaker;
    selectedDate;
    disableButton = true;

    @wire(MessageContext)
    messageContext;

    connectedCallback() {
        subscribe(this.messageContext, SPEAKER_SELECTED, (message) => {
            this.speakerId = message.speakerId;
            this.loadSpeaker();
        });
    }

    loadSpeaker() {
        getSpeaker({ speakerId: this.speakerId })
            .then(result => {
                this.speaker = result;
                this.disableButton = true;
            });
    }

    handleDate(event) {
        this.selectedDate = event.target.value;
        const today = new Date().toISOString().split('T')[0];

        if (this.selectedDate <= today) {
            this.showToast('Error', 'Date must be in the future', 'error');
            return;
        }

        checkAvailability({
            speakerId: this.speakerId,
            sessionDate: this.selectedDate
        }).then(isAvailable => {
            this.disableButton = !isAvailable;

            if (!isAvailable) {
                this.showToast(
                    'Error',
                    'Slot is already booked, try another date',
                    'error'
                );
            }
        });
    }

    createAssignment() {
        this.showToast('Success', 'Assignment created (demo)', 'success');
    }

    showToast(title, message, variant) {
        this.dispatchEvent(
            new ShowToastEvent({ title, message, variant })
        );
    }
}