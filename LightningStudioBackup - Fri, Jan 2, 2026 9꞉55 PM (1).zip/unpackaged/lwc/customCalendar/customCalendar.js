import { LightningElement, track } from 'lwc';

export default class CustomCalendar extends LightningElement {
    @track currentDate = new Date();
    @track selectedDate;

    today = new Date().setHours(0,0,0,0);
    weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

    get monthLabel() {
        return this.currentDate.toLocaleString('default', {
            month: 'long',
            year: 'numeric'
        });
    }

    get isPrevDisabled() {
        const firstDayOfMonth = new Date(
            this.currentDate.getFullYear(),
            this.currentDate.getMonth(),
            1
        );
        return firstDayOfMonth < this.today;
    }

    get dates() {
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const firstDay = new Date(year, month, 1).getDay();

        const dates = [];

        // Empty slots
        for (let i = 0; i < firstDay; i++) {
            dates.push({ value: `empty-${i}`, label: '', disabled: true, class: 'empty' });
        }

        // Month dates
        for (let day = 1; day <= daysInMonth; day++) {
            const dateValue = new Date(year, month, day);
            const isPast = dateValue.setHours(0,0,0,0) < this.today;

            dates.push({
                value: dateValue.toISOString(),
                label: day,
                disabled: isPast,
                class: isPast ? 'date disabled' : 'date'
            });
        }

        return dates;
    }

    prevMonth() {
        if (this.isPrevDisabled) return;
        this.currentDate = new Date(
            this.currentDate.getFullYear(),
            this.currentDate.getMonth() - 1,
            1
        );
    }

    nextMonth() {
        this.currentDate = new Date(
            this.currentDate.getFullYear(),
            this.currentDate.getMonth() + 1,
            1
        );
    }

    selectDate(event) {
        this.selectedDate = event.target.dataset.value;

        this.dispatchEvent(new CustomEvent('dateselect', {
            detail: this.selectedDate
        }));
    }
}